<div>
    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span>Back</span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter me-2"></i>
                                <span><?php echo e($this->my_office->name); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a wire:key="<?php echo e($office->id); ?>" wire:click="setOffice(<?php echo e($office->id); ?>)"
                                    href="javascript:void(0);" class="dropdown-item
                                    <?php echo e($office->id == $this->my_office->id ? ' active' : ''); ?>

                                    ">
                                    <i class="feather-users me-3"></i>
                                    <span><?php echo e($office->name); ?></span>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <div class="dropdown">
                            <input wire:model.live="date" type="date" class="btn btn-primary">
                            </input>
                        </div>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row">
                <!-- [Hadir] start -->
                <div class="col-xxl-4">
                    <div class="card stretch stretch-full">
                        <div class="card-header">
                            <h5 class="card-title">Karyawan yang sudah pulang - <?php echo e($this->presentUsers->count()); ?>/<?php echo e($this->presentUsers->count() + $this->absentUsers->count()); ?></h5>
                            <div class="card-header-action">
                                <div class="dropdown">
                                    <div data-bs-toggle="tooltip" title="Refresh">
                                        <a wire:click="getData" href="javascript:void(0);"
                                            class="avatar-text avatar-xs bg-warning"> </a>
                                    </div>
                                </div>
                                <div class="dropdown">
                                    <div data-bs-toggle="tooltip" title="Maximize/Minimize">
                                        <a href="javascript:void(0);" class="avatar-text avatar-xs bg-success"
                                            data-bs-toggle="expand"> </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body custom-card-action p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr class="border-b">
                                            <th scope="row">Nama</th>
                                            <!--[if BLOCK]><![endif]--><?php if(count($this->presentUsers) != 0): ?>
                                            <th>Waktu</th>
                                            <th>Status</th>
                                            <th>Bukti Foto</th>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->presentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr wire:key="<?php echo e($user->id); ?>">
                                            <td>
                                                <div class="d-flex align-items-center gap-3">
                                                    <a href="<?php echo e(url('/employee/view/' . $user->nip)); ?>"
                                                        class="avatar-image">
                                                        <img src="<?php echo e(url('assets/images/avatar/' . $user->photo)); ?>"
                                                            alt="" class="img-fluid" />
                                                    </a>
                                                    <a href="<?php echo e(url('/employee/view/' . $user->nip)); ?>">
                                                        <span class="d-block"><?php echo e($user->name); ?></span>
                                                    </a>
                                                </div>
                                            </td>
                                            <td> <?php echo e($user->attendanceData[0]->created_at->format('H:i')); ?></td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if($user->attendanceData[0]->time_deviation == 0): ?>
                                                <span class="badge bg-soft-success text-success">
                                                    Tepat Waktu
                                                </span>
                                                <?php elseif($user->attendanceData[0]->time_deviation > 0): ?>
                                                <span class="badge bg-soft-warning text-danger">
                                                    Terlambat
                                                </span>
                                                <?php elseif($user->attendanceData[0]->time_deviation < 0): ?> <span
                                                    class="badge bg-soft-warning text-danger">
                                                    Terlalu Cepat
                                                    </span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center gap-3">
                                                    <div class="wd-50 ht-50 rounded-2">
                                                        <a href="<?php echo e(url('assets/images/attendance/' . $user->attendanceData[0]->image)); ?>"
                                                            target="_blank">
                                                            <img src="<?php echo e(url('assets/images/attendance/' . $user->attendanceData[0]->image)); ?>"
                                                                alt="" class="img-fluid" />
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php if(count($this->presentUsers) == 0): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex justify-content-center align-items-center gap-3">
                                                    <span class="d-block">Belum ada yang pulang</span>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- [Hadir] start -->

                
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
    <script src="<?php echo e(url('assets/vendors/js/daterangepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendors/js/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendors/js/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dashboard-init.min.js')); ?>"></script>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('contentChanged', function(e) {
        loadScripts();
    });

    function loadScripts() {
        return new Promise((resolve, reject) => {
            $.getScript("<?php echo e(url('assets/vendors/js/daterangepicker.min.js')); ?>", function() {
                $.getScript("<?php echo e(url('assets/vendors/js/apexcharts.min.js')); ?>", function() {
                    $.getScript("<?php echo e(url('assets/vendors/js/circle-progress.min.js')); ?>", function() {
                        $.getScript("<?php echo e(url('assets/js/dashboard-init.min.js')); ?>", function() {
                            resolve();
                        }).fail(reject);
                    }).fail(reject);
                }).fail(reject);
            }).fail(reject);
        });
    }

    loadScripts();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/vendors/css/daterangepicker.min.css')); ?>" />
<?php $__env->stopPush(); ?><?php /**PATH /home/dana1241/public_html/damkar.samz.my.id/laravel/resources/views/dashboard/dashboard_check_out.blade.php ENDPATH**/ ?>