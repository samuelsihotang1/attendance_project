<div>
    <div class="nxl-content">
        <!-- [ page-header ] start -->
        <div class="page-header">
            <div class="page-header-right ms-auto">
                <div class="page-header-right-items">
                    <div class="d-flex d-md-none">
                        <a href="javascript:void(0)" class="page-header-right-close-toggle">
                            <i class="feather-arrow-left me-2"></i>
                            <span>Back</span>
                        </a>
                    </div>
                    <div class="d-flex align-items-center gap-2 page-header-right-items-wrapper">
                        <div class="dropdown">
                            <a class="btn btn-icon btn-light-brand" data-bs-toggle="dropdown" data-bs-offset="0, 10"
                                data-bs-auto-close="outside">
                                <i class="feather-filter me-2"></i>
                                <span class="text-truncate-1-line"><?php echo e($this->my_office->name); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a wire:key="<?php echo e($office->id); ?>" wire:click="setOffice(<?php echo e($office->id); ?>)"
                                    href="javascript:void(0);" class="dropdown-item
                                    <?php echo e($office->id == $this->my_office->id ? ' active' : ''); ?>

                                    ">
                                    <i class="feather-users me-3"></i>
                                    <span class="text-truncate-1-line"><?php echo e($office->name); ?></span>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        <a href="/employee/create" class="btn btn-primary">
                            <i class="feather-plus me-2"></i>
                            <span>Tambah Pegawai</span>
                        </a>
                    </div>
                </div>
                <div class="d-md-none d-flex align-items-center">
                    <a href="javascript:void(0)" class="page-header-right-open-toggle">
                        <i class="feather-align-right fs-20"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- [ page-header ] end -->
        <!-- [ Main Content ] start -->
        <div class="main-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card stretch stretch-full">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover" id="customerList">
                                    <thead>
                                        <tr>
                                            <th>Pegawai</th>
                                            <th>NIP</th>
                                            <th>Jabatan</th>
                                            <th class="text-end">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr wire:key="<?php echo e($user->id); ?>" class="single-item">
                                            <td>
                                                <a href="<?php echo e(url('employee/view/' . $user->nip)); ?>" class="hstack gap-3">
                                                    <div class="avatar-image avatar-md">
                                                        <img src="<?php echo e(url('assets/images/avatar/' . $user->photo)); ?>"
                                                            alt="" class="img-fluid">
                                                    </div>
                                                    <div>
                                                        <span class="text-truncate-1-line"><?php echo e($user->name); ?></span>
                                                    </div>
                                                </a>
                                            </td>
                                            <td><?php echo e($user->nip); ?></td>
                                            <td><?php echo e($user->rank); ?></td>
                                            <td>
                                                <div class="hstack gap-2 justify-content-end">
                                                    <a href="<?php echo e(url('employee/view/' . $user->nip)); ?>"
                                                        class="avatar-text avatar-md">
                                                        <i class="feather feather-eye"></i>
                                                    </a>
                                                    <div class="dropdown">
                                                        <a href="javascript:void(0)" class="avatar-text avatar-md"
                                                            data-bs-toggle="dropdown" data-bs-offset="0,21">
                                                            <i class="feather feather-more-horizontal"></i>
                                                        </a>
                                                        <ul class="dropdown-menu">
                                                            <li>
                                                                <a class="dropdown-item"
                                                                    href="<?php echo e(url('employee/edit/' . $user->nip)); ?>">
                                                                    <i class="feather feather-edit-3 me-3"></i>
                                                                    <span>Edit</span>
                                                                </a>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('contentChanged', function(e) {
        loadScripts();
    });

    function loadScripts() {
        return new Promise((resolve, reject) => {
            $.getScript("<?php echo e(url('assets/vendors/js/dataTables.min.js')); ?>", function() {
                $.getScript("<?php echo e(url('assets/vendors/js/dataTables.bs5.min.js')); ?>", function() {
                    $.getScript("<?php echo e(url('assets/vendors/js/select2.min.js')); ?>", function() {
                        $.getScript("<?php echo e(url('assets/vendors/js/select2-active.min.js')); ?>", function() {
                            $.getScript("<?php echo e(url('assets/js/customers-init.min.js')); ?>", function() {
                                resolve();
                            }).fail(reject);
                        }).fail(reject);
                    }).fail(reject);
                }).fail(reject);
            }).fail(reject);
        });
    }

    loadScripts();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/vendors/css/dataTables.bs5.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/vendors/css/select2.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/vendors/css/select2-theme.min.css')); ?>">
<?php $__env->stopPush(); ?><?php /**PATH /home/dana1241/public_html/damkar.samz.my.id/laravel/resources/views/employee/list.blade.php ENDPATH**/ ?>